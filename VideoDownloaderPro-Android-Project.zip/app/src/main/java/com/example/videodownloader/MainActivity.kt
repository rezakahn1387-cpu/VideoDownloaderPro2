package com.example.videodownloader

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        configureWebView()

        val shared = if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)
        } else null
        val initial = shared?.let { findUrl(it) } ?: "https://www.google.com"
        address.setText(initial)
        if (shared != null && looksLikeVideo(initial)) {
            downloadUrl(initial, null, null)
        } else {
            web.loadUrl(initial)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 8)
        }
        val title = TextView(this).apply {
            text = "Video Downloader Pro"
            textSize = 20f
            setPadding(4, 4, 4, 8)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        address = EditText(this).apply {
            hint = "آدرس سایت یا لینک ویدیو"
            singleLine = true
            setText("https://www.google.com")
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        row.addView(address, LinearLayout.LayoutParams(0, 52, 1f))
        val go = Button(this).apply {
            text = "برو"
            setOnClickListener { openAddress() }
        }
        row.addView(go)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val paste = Button(this).apply {
            text = "چسباندن لینک"
            setOnClickListener {
                address.requestFocus()
                address.setSelection(address.text.length)
                Toast.makeText(this@MainActivity, "لینک را در کادر بالا بچسبان و «برو» را بزن.", Toast.LENGTH_SHORT).show()
            }
        }
        val detect = Button(this).apply {
            text = "پیدا کردن ویدیو"
            setOnClickListener {
                web.evaluateJavascript(
                    "(function(){var v=document.querySelector('video'); return v ? (v.currentSrc || v.src || '') : '';})()"
                ) { value ->
                    val url = value?.trim('"')?.replace("\\u003C", "<") ?: ""
                    if (url.startsWith("http") && looksLikeVideo(url)) {
                        downloadUrl(url, null, null)
                    } else {
                        Toast.makeText(this@MainActivity, "لینک مستقیم ویدیو پیدا نشد؛ این سایت ممکن است پشتیبانی نشود.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        actions.addView(paste, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(detect, LinearLayout.LayoutParams(0, 48, 1f))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            max = 100
        }
        status = TextView(this).apply {
            text = "ویدیوهای قابل دانلود را فقط از منابع مجاز ذخیره کن."
            textSize = 12f
            setPadding(4, 4, 4, 4)
        }
        web = WebView(this)
        root.addView(title)
        root.addView(row)
        root.addView(actions)
        root.addView(progress, LinearLayout.LayoutParams(-1, 5))
        root.addView(status)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        address.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { openAddress(); true } else false
        }
    }

    private fun configureWebView() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                progress.visibility = View.VISIBLE
                status.text = "در حال باز کردن صفحه…"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                if (!url.isNullOrBlank()) address.setText(url)
                status.text = "برای لینک مستقیم، دکمه «پیدا کردن ویدیو» را امتحان کن."
            }
        }
        web.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            downloadUrl(url, userAgent, contentDisposition, mimeType)
        })
    }

    private fun openAddress() {
        var url = address.text.toString().trim()
        if (url.isEmpty()) return
        if (!url.contains("://")) {
            url = if (url.contains(".") && !url.contains(" ")) "https://$url"
            else "https://www.google.com/search?q=" + Uri.encode(url)
        }
        address.setText(url)
        if (looksLikeVideo(url)) downloadUrl(url, null, null) else web.loadUrl(url)
    }

    private fun downloadUrl(url: String, userAgent: String?, disposition: String?, mimeType: String? = null) {
        try {
            val uri = Uri.parse(url)
            if (uri.scheme != "https" && uri.scheme != "http") {
                Toast.makeText(this, "این نوع لینک پشتیبانی نمی‌شود.", Toast.LENGTH_LONG).show()
                return
            }
            val request = DownloadManager.Request(uri)
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                URLUtil.guessFileName(url, disposition, mimeType))
            request.setTitle(URLUtil.guessFileName(url, disposition, mimeType))
            request.setDescription("Video Downloader Pro")
            request.setAllowedOverMetered(true)
            request.setAllowedOverRoaming(false)
            if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrBlank()) request.addRequestHeader("Cookie", cookie)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "دانلود به پوشه Downloads اضافه شد."
            Toast.makeText(this, "دانلود شروع شد؛ اعلان‌های گوشی را بررسی کن.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "دانلود نشد؛ ممکن است سایت لینک مستقیم ندهد.", Toast.LENGTH_LONG).show()
        }
    }

    private fun looksLikeVideo(url: String): Boolean {
        val lower = url.lowercase()
        return listOf(".mp4", ".webm", ".mov", ".m4v", ".3gp", ".mp3", ".m4a").any { lower.contains(it) }
    }

    private fun findUrl(text: String): String {
        val match = Regex("https?://\\\\S+").find(text)
        return match?.value?.trimEnd(')', ']', '}', '.', ',', ';') ?: text.trim()
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
